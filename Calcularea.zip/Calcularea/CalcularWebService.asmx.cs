﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Calcularea
{
    /// <summary>
    /// Descripción breve de CalcularWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class CalcularWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        [WebMethod]
        public decimal cuadrado (decimal b, decimal a)
        {
            area c = new area();
            c.bases = b;
            c.altura = a;
            return c.cuadrado();
        }

        [WebMethod]
        public decimal triangulo (decimal a, decimal b)
        {
            area c = new area();
            return c.triangulo(a, b);
        }

        [WebMethod]
        public double circulo (double a, double b)
        {
            area c = new area();
            return c.circulo(a, b);
        }





    }
}

