﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Calcularea
{
    public class area
    {
        //reconozco que el area de un cuadrado es L * L pero es casi lo mismo jajaja
        public decimal altura { get; set;}
        public decimal bases { get; set; }
        public decimal cuadrado()
        {
            return bases * altura;
        }

        public decimal triangulo (decimal a, decimal b)
        {
            bases = b;
            altura = a;
            return bases * altura / 2;
        }

        public double circulo (double b, double a)
        {
            var resultado = b * a * 3.14;
            return resultado;
        }









    }
      

 
}